"""In This demonstration we will learn about the for loop & 
how it works first we will test it with strings & lists."""

print("\nTEST-1\n-------------------");

"""The value to the left of the 'in' operator is a variable
which holds the currently value it is on during its iterations
the one to the right of it is the string,list Or range of 
values it is itterating through."""

variable_string = "Python"

for letter in variable_string:
	print("\nCurrent letter : ",letter);

"""Note it will convert all letters to lowercase implicitly."""

print("\nTEST-1 List\n--------------------------");

variable_list = ["You","Me","Him","Her","Eachother"]

for current_value in variable_list: 
	print(current_value);

print("\nTEST-2\n--------------------------");

"""Okay so we have used the basic's now lets try some functions
that list's & tuples offer."""

for current_index in range(0,len(variable_list)):
	print("\nIndex Value : ",variable_list[current_index]);

"""Note that the 'range()' function will still work if you 
do not provide the start value but for good practice & so it
looks alot more sensible just provide it."""

print("\nTEST-3\n-------------------------");

"""Now just like the while loop we will make use of the else
statement with the for loop but to keep it so that we are 
learning something new i will throw in  the first operation
that both these loops can make use of the 'break' operation."""

for letter in variable_string:
	print(letter);
	if(letter == "o"):
		break;
else:
	print("\n\nEND of for loop Goodbye.");

"""As you can see the full word was not printed and neither
was the text in the else statement that is because anything
associated with the while loop that has not already been run
when the break is run is skipped."""

print("\nTEST - 3 More Operations\n--------------------------");

"""In this demonstration we are going to make use of the 'continue'
operation."""

for letter in 'Python':
	if(letter == "y"):
		continue;
	print(letter);
else:
	print("\n\nEND of the for loop Goodbye.");

"""As you can see the loop printed everything now but the 
y in python because of the use of the continue during its 
itteration it causes the loop not to stop but to stop the
itteration and return the control back to the top of the 
loop causing it to skip over that letter."""


"""Now we could demonstrate the pass operation but as it is
a null operation a see very little use in it as it essentially
does not do anything."""
 