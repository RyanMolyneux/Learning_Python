"""This test will consist of both testing of different types
of loops and the functions they can perform."""

print("\nTEST-1\n--------------------------");

"""This first test is on just the simple use of a while loop
to count numbers up as far as 10"""

variable_1 = 0

while (variable_1 != 11):
	print("\n",variable_1);
	variable_1+=1

print("\nTEST-2\n-------------------------");

"""This test makes use of the else statement 
with the while loop again we will be counting but as far
as 20 this time."""

while(variable_1<21):
	print("\n",variable_1);
	variable_1+=1;
else:
	print("Wooohooo we have counted as far as 20.");

print("\nTEST-3\n-----------------------------------");

"""Now that we Know how to use the for loop with & without
the use of the else statement we will now try create & talk
about a 'infinite loop' this is when the loop is stuck because
it never resolves to false therfore it will never exit the 
loop."""

variable_string = "THIS IS A NEVER ENDING LOOP."

while (True):
	print("\n\n",variable_string);