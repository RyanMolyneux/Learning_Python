"""Test 2 is used to Demonstrate the use of 'is' & 'is not' operator's similar to 'in' & 'not in' operators but instead of searching
for a value it is instead checking if the variables memory location points to the same memory location as the other variable passed in.
"""


print("\nTEST-1\n------------------------");

"""First we will test the 'is' operator which will return true if the two variables point to the same memory location."""

variable_1 = 20;

variable_2 = variable_1;

if(variable_2 is variable_1):
	print("\n\nBoth Variables point to the same memory location.");
else:
	print("\n\nBoth Variables do not point to the same memory location.");

variable_2 = 30;

print("\nTEST-2\n------------------------------");

"""Now we will test the 'is not' operator which test's if both variables do not point to the same memory location if they do it returns
true else if will return false."""

if(variable_1 is not variable_2):
	print("\n\nBoth Variables no longer point to the same memory location.");
else:
	print("\n\nBoth Variables still point to the same location in memory.");