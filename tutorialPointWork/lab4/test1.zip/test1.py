"""This is used to check if value passed in is in the data set
simplified to remove unecessary clutter so essentially the
'in' operator returns true if the value passed in is in the list
/ tuple rember tupples are essentially lists which cannot be edited
."""
"""Variables"""
variable_1 = 30
variable_2 = 70
list = [20,30,40,50,80,90]

""" Demonstration of the 'in' operator first.""" 
print("\n\nTEST-1\n-------------------------");

if (variable_2 in list): 
	print("\n\nVariable 2 exists within the list");
elif(variable_1 in list):
	print("\n\nVariable 2 does not exist within the list but Variable 1 does.");
else:
	print("\n\nNeither Variable exists within our list.");

""" In the first test we used the 'in' operator which is used to check if a variable is in a data set like a tuple or list this time
we will the 'not in' operator to check if a specific value is not in the data set and this time we will do it using our tuple."""

print("\n\nTEST-2\n------------------------");


tuple = (10,20,50,70);

if (variable_2 not in tuple):
	print("\n\nVariable 2 is none existent in the tuple.");
elif (variable_1 not in tuple):
	print("\n\nVairble 2 is existent in the tuple but Variable 1 is not.");
else : 
	print("\n\nNeither Variable exists witin our tuple.");